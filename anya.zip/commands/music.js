module.exports = ({
name: "Help",
code: `$author[ Anya 🎶 ;https://media.discordapp.net/attachments/945534689484099584/1080115858451476501/logo.gif]
$description[

 **> Music Menu 🎶 ** 
**$getServerVar[prefix]play** - Play some music!. 
**$getServerVar[prefix]nowplaying** - See the current playing song.
**$getServerVar[prefix]pause** - Pause the current playing song.
**$getServerVar[prefix]lyrics** - Get lyrics from the current playing or a specific song.
**$getServerVar[prefix]loop** - Loops the current song.
**$getServerVar[prefix]skip** - Skips the current playing song.
**$getServerVar[prefix]stop** - Stops the current playing song.
**$getServerVar[prefix]volume** - Change the music volume.

$image[https://cdn.discordapp.com/attachments/945534689484099584/1080122892467060896/tenor.gif]

$color[RANDOM]
$footer[@$username]
$addTimestamp]`

})