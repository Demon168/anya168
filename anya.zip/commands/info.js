module.exports = {
  name:"info",
  code:`$author[Anya ;https://media.discordapp.net/attachments/872700345388773396/873052319334412298/v.gif]
  $title[__**Information Bots**__]
  $description[
  
  ** Name : **  Anya
  
  **Location : ** Cambodia  :flag_kh:

  $addField[ **Developer By ** : ;$userTag[$botOwnerID]]

  ]
  $color[FFFF00]
  $image[https://media.discordapp.net/attachments/945534689484099584/1080115826004344923/Difj.gif?width=962&height=361]
  $footer[@$username]
  $addTimestamp
  `
}