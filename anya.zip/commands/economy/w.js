module.exports = {
  
  name: "test",
  aliases: ['w'],
  code: `$description[
  <:money:1082505149576138785>]
  `
}